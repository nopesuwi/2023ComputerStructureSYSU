This is the C++ implementation of Graspan

